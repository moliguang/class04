<template>
  <div class="find">
    <!-- 新手练习场 -->
    <div class="find_practice">
      <div class="little_title">
        <div class="little_title_t">新手练习场</div>
        <div class="little_title_m">更多</div>
      </div>
      <div class="find_practice_content">
        <div class="left">
          <img class="left_img" src="images/home_practice.png" alt />
        </div>
        <div class="right">
          <div class="text1 right_t">模拟练习场</div>
          <div
            class="text2 right_des"
          >在模拟练习体验真实操盘交易，提升您的炒股在模拟练习体验真实操盘交易，提升您的炒股在模拟练习体验真实操盘交易，提升您的炒股在模拟练习体验真实操盘</div>
          <div class="text2 right_num">2022人参赛</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { F700108 } from "@/service/api.js";
export default {
  name: "Find",
  data() {
    return {
      practiceInfo: {}
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    init() {
      Promise.all([this.F700108()])
        .then(result => {
          console.log("请求成功=", result);
        })
        .catch(e => {
          console.log(e);
        });
    },
    // 获取练习场信息
    async F700108() {
      let res = await F700108({
        channel_type: "2",
        act_type_subset: "15",
        act_type: "0"
      });
      if (res.data.code === 0) {
        let practiceInfo = res.data.data[0];
        let { image_head_info, image } = practiceInfo;
        practiceInfo.imgUrl = image_head_info + image;
        this.practiceInfo = practiceInfo;
        return res;
      }
    }
  }
};
</script>

<style lang="scss">
.find {
  &_practice {
    background-color: #fff;
    &_content {
      display: flex;
      flex-direction: row;
      padding: 0 15px;
      align-items: center;
      justify-content: space-between;
      height: 90px;
      .left {
        margin-right: 10px;
        &_img {
          width: 60px;
          height: 60px;
        }
      }
      .right {
        &_t {
          margin-bottom: 3px;
        }
        &_des {
          width: 275px;
          margin-bottom: 5px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .text1 {
          font-size: 14px;
          font-weight: 500;
          color: rgba(34, 34, 34, 1);
          line-height: 20px;
        }
        .text2 {
          font-size: 12px;
          font-weight: 400;
          color: rgba(136, 136, 136, 1);
          line-height: 16px;
        }
      }
    }
  }
  .little_title {
    position: relative;
    display: flex;
    padding: 0 15px;
    height: 50px;
    justify-content: space-between;
    align-items: center;
    &_t {
      font-size: 16px;
      font-weight: 400;
      color: rgba(34, 34, 34, 1);
      line-height: 22px;
    }
    &_m {
      font-size: 14px;
      font-weight: 400;
      color: rgba(59, 123, 230, 1);
      line-height: 20px;
    }
  }
  .little_title:after {
    position: absolute;
    content: "";
    width: 100%;
    height: 1px;
    background-color: #f0f0f0;
    bottom: 0;
    left: 0;
  }
}
</style>

