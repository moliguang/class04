import Vue from 'vue' // vue框架
import App from './App.vue' // 根组件
import router from './router' // 前端路由
import store from './store' // vuex 数据共享

import 'lib-flexible';

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
