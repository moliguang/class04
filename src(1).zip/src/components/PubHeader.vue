<template>
  <div class="pub_header">
    <div>
      <img class="pub_header_back" src="images/back.png" alt="">
    </div>
    <div class="pub_header_btn">
      <div @click="itemClick('1')" class="btn" :class="{btn_active:currentIndex === '1'}">发现</div>
      <div @click="itemClick('2')" class="btn" :class="{btn_active:currentIndex === '2'}">我的</div>
    </div>
    <div>
      <img class="pub_header_share" src="images/share_icon.png" alt="">
    </div>
  </div>
</template>

<script>
  export default {
    name:"PubHeader",
    data () {
      return {
        currentIndex: '1'
      }
    },
    methods:{
      itemClick(currentIndex){
        this.currentIndex = currentIndex;
      }
    }
  }
</script>

<style lang="scss">
.pub_header{
  display:flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  background-color: #3B7BE6;
  padding:0px 10px;
  height: 44px;
  color: #fff;
  &_back{
    width: 16px;
    height: 24px;
  }
  &_btn{
    display:flex;
    flex-direction: row;
    .btn{
      width: 56px;
      height: 28px;
      text-align: center;
      border: 1px solid #fff;
      border-right: none;
      box-sizing: border-box;
      line-height: 28px;
    }
    .btn:nth-of-type(2){
      border-left: none;
      border-right: 1px solid #fff;
    }
    .btn_active{
      background-color: #fff;
      color: #3B7BE6;
    }
  }
  &_share{
    width: 24px;
    height: 24px;
  }
}
</style>