<template>
  <div class="find">
    this is find page
  </div>
</template>
<script>
export default {
  name:'Find',
  create () {
    debugger;
  }
}
</script>
<style>
.find{
  font-size: 20px;
  color:red;
}
</style>