<template>
  <div class="find">
    这是发现页
  </div>
</template>

<script>
  export default {
    name: "Find"
  }
</script>

<style lang="scss">
.find{
  
}
</style>

