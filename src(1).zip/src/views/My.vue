<template>
  <div class="my">
   <div>牛人汇</div>
  </div>
</template>
<script>
export default {
  name: 'My',
}
</script>
<style lang="scss">
.my{
  color:red;
}
</style>
