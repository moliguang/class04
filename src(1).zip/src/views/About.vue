<template>
  <div class="about">
    <div>这是about页面</div>
  </div>
</template>
